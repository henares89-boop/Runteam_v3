import React, { useMemo, useState } from 'react';
import { View, Text, ScrollView, Pressable, TextInput, Alert } from 'react-native';
import { supabase } from './supabase';
import { Avatar, Btn, C, Chip, Chips, Pill, Seg, Sheet, s } from './ui';
import {
  DIAI, addDays, addMonths, forUser, fmtLong, fmtMin, fmtMonth, fmtRange, fmtDur, goalText, mondayOf, num, paceText, parse,
  sportInfo, sportKey, stepLine, taskStatus, tDate, todayStr, typeInfo, weekStats, weekdayIdx,
} from './util';

export function WeekForm({ ws, focus, onClose, reload }) {
  const [t, setT] = useState(focus || '');
  const save = async () => {
    const { error } = await supabase.from('weeks').upsert({ week_start: ws, focus: t.trim() });
    if (error) return Alert.alert('Error', error.message);
    reload(); onClose();
  };
  return (
    <Sheet title={'Semana ' + fmtRange(ws)} onClose={onClose} footer={<Btn title="Guardar" onPress={save} />}>
      <Text style={s.label}>OBJETIVO Y MENSAJE DEL COACH PARA LA SEMANA</Text>
      <TextInput style={[s.input, { minHeight: 140, textAlignVertical: 'top' }]} multiline value={t} onChangeText={setT} placeholder="Ej. Semana de carga. Prioridad: las series del jueves y la tirada larga." />
    </Sheet>
  );
}

export default function Calendar({ me, data, reload, go }) {
  const today = todayStr();
  const isCoach = me.role === 'coach';
  const runners = data.profiles.filter((p) => p.role !== 'socio');
  const [sel, setSel] = useState(today);
  const [mode, setMode] = useState('month');
  const [viewer, setViewer] = useState(me.role === 'socio' ? 'all' : me.id);

  const nm = (id) => (data.profiles.find((p) => p.id === id) || {}).name || '—';
  const cnt = (tt, id) => data.cc.filter((c) => c.target_type === tt && c.target_id === String(id)).length;

  const tasksByDate = useMemo(() => {
    const m = {};
    data.tasks.forEach((t) => {
      const d = tDate(t); if (!d) return;
      if (viewer !== 'all' && !forUser(t, viewer)) return;
      (m[d] = m[d] || []).push(t);
    });
    return m;
  }, [data.tasks, viewer]);
  const actsByDate = useMemo(() => {
    const m = {};
    data.acts.forEach((a) => { if (viewer !== 'all' && a.user_id !== viewer) return; (m[a.date] = m[a.date] || []).push(a); });
    return m;
  }, [data.acts, viewer]);

  const ws = mondayOf(sel);
  const first = sel.slice(0, 8) + '01';
  const monthEnd = addDays(addMonths(first, 1), -1);
  const rows = mode === 'week' ? 1 : Math.ceil((weekdayIdx(first) + parse(monthEnd).getDate()) / 7);
  const gridStart = mode === 'week' ? ws : mondayOf(first);

  const prev = () => setSel(mode === 'week' ? addDays(sel, -7) : addMonths(sel, -1));
  const next = () => setSel(mode === 'week' ? addDays(sel, 7) : addMonths(sel, 1));

  const toggleDone = async (t) => {
    const mine = data.done.some((d) => d.task_id === t.id && d.user_id === me.id);
    const q = mine ? supabase.from('task_done').delete().eq('task_id', t.id).eq('user_id', me.id) : supabase.from('task_done').insert({ task_id: t.id, user_id: me.id });
    const { error } = await q; if (error) Alert.alert('Error', error.message); reload();
  };

  const weekTasks = data.tasks.filter((t) => { const d = tDate(t); return d && d >= ws && d <= addDays(ws, 6); });
  const prevTasks = data.tasks.filter((t) => { const d = tDate(t); return d && d >= addDays(ws, -7) && d <= addDays(ws, -1); });
  const copyPrev = async () => {
    const rowsIns = prevTasks.map((t) => {
      const { id, created_at, ...r } = t; const d = addDays(tDate(t), 7);
      return { ...r, date: d, week_start: mondayOf(d), day: weekdayIdx(d) };
    });
    const { error } = await supabase.from('tasks').insert(rowsIns);
    if (error) Alert.alert('Error', error.message); reload();
  };
  const wk = data.weeks.find((w) => w.week_start === ws);

  /* ---- tarjeta de sesión ---- */
  const taskCard = (t, date) => {
    const [label, color] = typeInfo(t.type); const sp = sportInfo(t.sport || 'run');
    if (t.type === 'descanso') {
      return (
        <View key={t.id} style={[s.card, { borderLeftWidth: 5, borderLeftColor: color }]}>
          <View style={[s.row, { justifyContent: 'space-between' }]}>
            <Text style={{ fontWeight: '700' }}>😴 {t.title || 'Descanso'}</Text>
            {isCoach && <Text style={{ color: C.muted }} onPress={() => go('task', { task: t })}>Editar</Text>}
          </View>
          {!!t.notes && <Text style={{ marginTop: 4 }}>{t.notes}</Text>}
        </View>
      );
    }
    let status;
    if (viewer !== 'all') {
      const x = taskStatus(t, viewer, data);
      status = x.done ? <Pill kind="ok" label={'✓ Hecha' + (x.how === 'auto' ? ' · con actividad' : '')} />
        : x.partial ? <Pill kind="warn" label={'Parcial · ' + (x.km ? num(x.km) + ' km' : '') + (x.min ? ' ' + fmtMin(x.min) : '')} />
          : date < today ? <Pill kind="warn" label="No hecha" /> : <Pill label="Pendiente" />;
    } else {
      const rs = runners.filter((r) => forUser(t, r.id)); const ok = rs.filter((r) => taskStatus(t, r.id, data).done).length;
      status = <Pill kind={ok && ok === rs.length ? 'ok' : undefined} label={ok + '/' + rs.length + ' hechas'} />;
    }
    const mine = viewer === me.id && forUser(t, me.id) && me.role !== 'socio';
    const meDone = data.done.some((x) => x.task_id === t.id && x.user_id === me.id);
    const meStatus = mine ? taskStatus(t, me.id, data) : null;
    const g = goalText(t);
    return (
      <View key={t.id} style={[s.card, { borderLeftWidth: 5, borderLeftColor: color }]}>
        <View style={[s.row, { justifyContent: 'space-between', alignItems: 'flex-start' }]}>
          <View style={{ flex: 1 }}>
            <Text style={{ fontWeight: '800', fontSize: 16 }}>{sp[1]} {t.title}</Text>
            <Text style={s.muted}>{[label, g, t.assignee ? 'Para ' + nm(t.assignee).split(' ')[0] : ''].filter(Boolean).join(' · ')}</Text>
          </View>
          {isCoach && <Text style={{ color: C.muted, padding: 4 }} onPress={() => go('task', { task: t })}>Editar</Text>}
        </View>
        {Array.isArray(t.steps) && t.steps.length > 0 && (
          <View style={{ marginTop: 8, backgroundColor: C.bg, borderRadius: 10, padding: 10 }}>
            {t.steps.map((st, i) => <Text key={st.id || i} style={{ fontSize: 14, marginVertical: 1 }}>• {stepLine(st)}</Text>)}
          </View>
        )}
        {!!t.notes && <Text style={{ marginTop: 8 }}>{t.notes}</Text>}
        <View style={[s.row, { marginTop: 10, flexWrap: 'wrap' }]}>
          {status}
          {mine && meStatus && !meStatus.done && <Btn small title="Registrar" onPress={() => go('manual', { init: { date, sport: t.sport || 'run', km: t.km, min: t.goal_min } })} />}
          {mine && (meDone || !(meStatus && meStatus.done)) && <Btn small kind="ghost" title={meDone ? 'Quitar marca' : 'Marcar hecha'} onPress={() => toggleDone(t)} />}
          <Btn small kind="ghost" title={'💬 ' + cnt('task', t.id)} onPress={() => go('comments', { target: { type: 'task', id: t.id, title: t.title } })} />
        </View>
      </View>
    );
  };

  const actRow = (a) => {
    const sp = sportInfo(sportKey(a.sport));
    const pace = paceText(sportKey(a.sport), a.moving_sec, a.km);
    return (
      <Pressable key={a.id} onPress={() => go('comments', { target: { type: 'activity', id: a.id, title: a.name } })} style={{ backgroundColor: C.okSoft, borderRadius: 12, padding: 10, marginVertical: 4 }}>
        <View style={[s.row, { justifyContent: 'space-between' }]}>
          <Text style={{ flex: 1 }}><Text style={{ fontWeight: '800' }}>{sp[1]} {Number(a.km) > 0 ? num(a.km, 2) + ' km · ' : ''}{fmtDur(a.moving_sec)}</Text>{pace ? ' · ' + pace : ''}</Text>
          <Text style={s.muted}>💬 {cnt('activity', a.id)}</Text>
        </View>
        <Text style={s.muted}>{viewer === 'all' ? nm(a.user_id) + ' · ' : ''}{a.name} · {a.source === 'import' ? 'Strava (archivo)' : 'manual'}</Text>
      </Pressable>
    );
  };

  const dayBlock = (date, compact) => {
    const ts = tasksByDate[date] || [], as = actsByDate[date] || [];
    return (
      <View key={date} style={{ marginTop: 14 }}>
        <View style={[s.row, { justifyContent: 'space-between' }]}>
          <Pressable onPress={() => setSel(date)} style={{ flex: 1 }}>
            <Text style={{ fontSize: 16, fontWeight: '800', color: date === sel && compact ? C.accent : C.text }}>{fmtLong(date)}{date === today ? ' · HOY' : ''}</Text>
          </Pressable>
          {isCoach && <Btn small title="+ Sesión" onPress={() => go('task', { date })} />}
        </View>
        {ts.map((t) => taskCard(t, date))}
        {as.map(actRow)}
        {!ts.length && !as.length && <Text style={[s.muted, { marginTop: 6 }]}>{isCoach ? 'Sin sesiones. Pulsa "+ Sesión" para añadir una.' : 'Día libre.'}</Text>}
      </View>
    );
  };

  /* ---- cuadrícula ---- */
  const cells = [];
  for (let r = 0; r < rows; r++) {
    const rowCells = [];
    for (let c = 0; c < 7; c++) {
      const date = addDays(gridStart, r * 7 + c);
      const inMonth = date.slice(0, 7) === sel.slice(0, 7) || mode === 'week';
      const isSel = date === sel;
      const ts = (tasksByDate[date] || []).filter((t) => t.type !== 'descanso');
      const rest = (tasksByDate[date] || []).some((t) => t.type === 'descanso');
      const km = (actsByDate[date] || []).reduce((x, a) => x + Number(a.km || 0), 0);
      rowCells.push(
        <Pressable key={date} onPress={() => setSel(date)} style={{ flex: 1, minHeight: mode === 'week' ? 70 : 58, margin: 1.5, borderRadius: 10, alignItems: 'center', paddingTop: 4, backgroundColor: isSel ? C.soft : C.card, borderWidth: isSel ? 2 : 1, borderColor: isSel ? C.accent : C.line, opacity: inMonth ? 1 : 0.4 }}>
          <View style={{ width: 22, height: 22, borderRadius: 11, alignItems: 'center', justifyContent: 'center', backgroundColor: date === today ? C.accent : 'transparent' }}>
            <Text style={{ fontSize: 12, fontWeight: '700', color: date === today ? '#fff' : C.text }}>{parse(date).getDate()}</Text>
          </View>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', marginTop: 3, gap: 3, paddingHorizontal: 2 }}>
            {ts.slice(0, 4).map((t) => {
              const done = viewer !== 'all' && taskStatus(t, viewer, data).done;
              const col = typeInfo(t.type)[1];
              return <View key={t.id} style={{ width: 9, height: 9, borderRadius: 5, borderWidth: 2, borderColor: col, backgroundColor: done || viewer === 'all' ? col : 'transparent' }} />;
            })}
            {rest && <Text style={{ fontSize: 9 }}>😴</Text>}
          </View>
          {km > 0 && <Text style={{ fontSize: 10, color: C.ok, fontWeight: '700', marginTop: 2 }}>{num(km, 0)} km</Text>}
        </Pressable>,
      );
    }
    cells.push(<View key={r} style={{ flexDirection: 'row' }}>{rowCells}</View>);
  }

  /* ---- resumen semanal ---- */
  const statRunners = viewer === 'all' ? runners : runners.filter((r) => r.id === viewer);
  const weekCard = (
    <View style={s.card}>
      <View style={[s.row, { justifyContent: 'space-between' }]}>
        <Text style={{ fontWeight: '800', fontSize: 15 }}>Semana {fmtRange(ws)}{ws === mondayOf(today) ? ' · actual' : ''}</Text>
        {isCoach && <Btn small kind="ghost" title="Objetivo" onPress={() => go('week', { ws, focus: wk && wk.focus })} />}
      </View>
      {!!(wk && wk.focus) && <Text style={{ marginTop: 6 }}>{wk.focus}</Text>}
      {statRunners.map((r) => {
        const st = weekStats(r.id, ws, data); const pc = st.total ? Math.min(100, (st.done / st.total) * 100) : 0;
        return (
          <View key={r.id} style={{ marginTop: 10 }}>
            <View style={[s.row, { justifyContent: 'space-between' }]}>
              <View style={s.row}><Avatar name={r.name} id={r.id} size={22} /><Text style={{ fontWeight: '700' }}>{r.id === me.id ? 'Yo' : (r.name || '').split(' ')[0]}</Text></View>
              <Text style={s.muted}>{st.total ? st.done + '/' + st.total + ' sesiones · ' : ''}{num(st.km)} km · {fmtMin(st.min)}</Text>
            </View>
            {st.total > 0 && <View style={{ height: 7, borderRadius: 9, backgroundColor: C.line, marginTop: 5 }}><View style={{ height: 7, borderRadius: 9, width: pc + '%', backgroundColor: pc >= 100 ? C.ok : C.accent }} /></View>}
          </View>
        );
      })}
      <View style={[s.row, { marginTop: 10, flexWrap: 'wrap' }]}>
        <Btn small kind="ghost" title={'💬 Comentarios de la semana (' + cnt('week', ws) + ')'} onPress={() => go('comments', { target: { type: 'week', id: ws, title: 'Semana ' + fmtRange(ws) } })} />
        {isCoach && !weekTasks.length && prevTasks.length > 0 && <Btn small title="Copiar semana anterior" onPress={copyPrev} />}
      </View>
    </View>
  );

  return (
    <ScrollView contentContainerStyle={{ padding: 14, paddingBottom: 40 }}>
      <Chips>
        {me.role !== 'socio' && <Chip label="Yo" on={viewer === me.id} onPress={() => setViewer(me.id)} />}
        <Chip label="Equipo" on={viewer === 'all'} onPress={() => setViewer('all')} />
        {runners.filter((r) => r.id !== me.id).map((r) => <Chip key={r.id} label={(r.name || '').split(' ')[0]} on={viewer === r.id} onPress={() => setViewer(r.id)} />)}
      </Chips>

      <View style={[s.row, { justifyContent: 'space-between', marginVertical: 6 }]}>
        <Btn kind="ghost" title="‹" onPress={prev} style={{ width: 48 }} />
        <Pressable onPress={() => setSel(today)} style={{ alignItems: 'center' }}>
          <Text style={{ fontSize: 18, fontWeight: '800', textTransform: 'capitalize' }}>{mode === 'week' ? fmtRange(ws) : fmtMonth(sel)}</Text>
          <Text style={{ color: C.accent, fontSize: 12, fontWeight: '700' }}>Ir a hoy</Text>
        </Pressable>
        <Btn kind="ghost" title="›" onPress={next} style={{ width: 48 }} />
      </View>
      <Seg options={[['month', 'Mes'], ['week', 'Semana']]} value={mode} onChange={setMode} />

      <View style={{ flexDirection: 'row', marginTop: 10 }}>
        {DIAI.map((l) => <Text key={l} style={{ flex: 1, textAlign: 'center', color: C.muted, fontWeight: '700', fontSize: 12 }}>{l}</Text>)}
      </View>
      {cells}
      <View style={[s.row, { flexWrap: 'wrap', marginTop: 6, gap: 10 }]}>
        {['rodaje', 'series', 'tempo', 'larga', 'competicion'].map((k) => (
          <View key={k} style={s.row}><View style={{ width: 9, height: 9, borderRadius: 5, backgroundColor: typeInfo(k)[1] }} /><Text style={{ fontSize: 11, color: C.muted }}>{typeInfo(k)[0]}</Text></View>
        ))}
      </View>

      {weekCard}

      {mode === 'month' ? dayBlock(sel, false) : [0, 1, 2, 3, 4, 5, 6].map((i) => dayBlock(addDays(ws, i), true))}
    </ScrollView>
  );
}
