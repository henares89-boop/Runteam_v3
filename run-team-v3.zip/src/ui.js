import React from 'react';
import { Pressable, Text, View, StyleSheet, ScrollView, KeyboardAvoidingView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { DIAI, MES, addDays, fmtLong, mondayOf, parse, todayStr } from './util';

export const C = {
  bg: '#f6f5f2', card: '#fff', text: '#1b1b1f', muted: '#6b6b76', line: '#e6e4df', accent: '#fc4c02', soft: '#fff0ea',
  ok: '#1f9d63', okSoft: '#e5f6ee', warn: '#c77700', warnSoft: '#fff4de', danger: '#d93a3a',
};
export const s = StyleSheet.create({
  card: { backgroundColor: C.card, borderRadius: 16, padding: 14, marginVertical: 6, borderWidth: 1, borderColor: C.line },
  row: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  h2: { fontSize: 12, letterSpacing: 1, color: C.muted, fontWeight: '700', marginTop: 16, marginBottom: 4, textTransform: 'uppercase' },
  muted: { color: C.muted, fontSize: 13 },
  input: { backgroundColor: C.bg, borderWidth: 1, borderColor: C.line, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10, minHeight: 46, fontSize: 16, color: C.text, marginTop: 4 },
  label: { fontSize: 12, color: C.muted, fontWeight: '700', marginTop: 14, marginBottom: 2 },
});

export const Btn = ({ title, onPress, kind, small, disabled, style }) => {
  const bg = kind === 'ghost' || kind === 'danger' ? C.card : C.accent;
  const fg = kind === 'ghost' ? C.text : kind === 'danger' ? C.danger : '#fff';
  return (
    <Pressable onPress={onPress} disabled={disabled}
      style={[{ backgroundColor: bg, borderWidth: kind ? 1 : 0, borderColor: C.line, paddingVertical: small ? 7 : 12, paddingHorizontal: small ? 11 : 16, borderRadius: 12, opacity: disabled ? 0.5 : 1, alignItems: 'center', justifyContent: 'center' }, style]}>
      <Text style={{ color: fg, fontWeight: '700', fontSize: small ? 13 : 15 }}>{title}</Text>
    </Pressable>
  );
};

export const Chips = ({ children }) => (
  <ScrollView horizontal showsHorizontalScrollIndicator={false} keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingVertical: 4 }}>{children}</ScrollView>
);
export const Chip = ({ label, on, onPress, color }) => (
  <Pressable onPress={onPress} style={{ paddingVertical: 7, paddingHorizontal: 13, borderRadius: 99, borderWidth: 1, marginRight: 8, borderColor: on ? (color || C.accent) : C.line, backgroundColor: on ? (color ? color + '22' : C.soft) : C.card }}>
    <Text style={{ color: on ? (color || C.accent) : C.text, fontWeight: on ? '700' : '400' }}>{label}</Text>
  </Pressable>
);
export const Pill = ({ label, kind }) => (
  <View style={{ alignSelf: 'flex-start', borderRadius: 99, paddingVertical: 3, paddingHorizontal: 10, backgroundColor: kind === 'ok' ? C.okSoft : kind === 'warn' ? C.warnSoft : kind === 'coach' ? C.soft : C.line }}>
    <Text style={{ fontSize: 12, fontWeight: '700', color: kind === 'ok' ? C.ok : kind === 'warn' ? C.warn : kind === 'coach' ? C.accent : C.muted }}>{label}</Text>
  </View>
);
export const Seg = ({ options, value, onChange }) => (
  <View style={{ flexDirection: 'row', backgroundColor: C.line, borderRadius: 12, padding: 3 }}>
    {options.map(([k, l]) => (
      <Pressable key={k} onPress={() => onChange(k)} style={{ flex: 1, paddingVertical: 8, borderRadius: 10, alignItems: 'center', backgroundColor: value === k ? C.card : 'transparent' }}>
        <Text style={{ fontWeight: value === k ? '800' : '500', color: value === k ? C.text : C.muted }}>{l}</Text>
      </Pressable>
    ))}
  </View>
);

const AVC = ['#fc4c02', '#3e63dd', '#2e9e6b', '#8e4ec6', '#d6409f', '#12a594', '#f08a24', '#e5484d'];
export const Avatar = ({ name, id, size = 32 }) => {
  let h = 0; String(id || name || '').split('').forEach((c) => { h = (h * 31 + c.charCodeAt(0)) >>> 0; });
  const ini = (String(name || '?').trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join('') || '?').toUpperCase();
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: AVC[h % AVC.length], alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ color: '#fff', fontWeight: '800', fontSize: size * 0.4 }}>{ini}</Text>
    </View>
  );
};

// Selector de fecha: tira de 7 días con flechas de semana
export function DateStrip({ value, onChange }) {
  const ws = mondayOf(value); const d = parse(value);
  return (
    <View>
      <View style={[s.row, { justifyContent: 'space-between', marginBottom: 6 }]}>
        <Btn small kind="ghost" title="‹" onPress={() => onChange(addDays(value, -7))} />
        <Text style={{ fontWeight: '700' }}>{MES[d.getMonth()]} {d.getFullYear()}</Text>
        <Btn small kind="ghost" title="›" onPress={() => onChange(addDays(value, 7))} />
      </View>
      <View style={{ flexDirection: 'row', gap: 4 }}>
        {DIAI.map((l, i) => {
          const dt = addDays(ws, i); const on = dt === value;
          return (
            <Pressable key={dt} onPress={() => onChange(dt)} style={{ flex: 1, alignItems: 'center', paddingVertical: 8, borderRadius: 10, borderWidth: 1, borderColor: on ? C.accent : C.line, backgroundColor: on ? C.soft : C.card }}>
              <Text style={{ fontSize: 11, color: C.muted }}>{l}</Text>
              <Text style={{ fontWeight: '800', color: on ? C.accent : C.text }}>{parse(dt).getDate()}</Text>
            </Pressable>
          );
        })}
      </View>
      <View style={[s.row, { justifyContent: 'space-between', marginTop: 6 }]}>
        <Text style={s.muted}>{fmtLong(value)}</Text>
        <Text style={{ color: C.accent, fontWeight: '700' }} onPress={() => onChange(todayStr())}>Hoy</Text>
      </View>
    </View>
  );
}

// Pantalla a pantalla completa con cabecera, contenido con scroll y pie fijo
export function Sheet({ title, onClose, children, footer }) {
  const ins = useSafeAreaInsets();
  return (
    <KeyboardAvoidingView behavior="padding" style={{ flex: 1, backgroundColor: C.bg, paddingTop: ins.top, paddingBottom: footer ? 0 : ins.bottom }}>
      <View style={[s.row, { padding: 14, paddingBottom: 6, justifyContent: 'space-between' }]}>
        <Text style={{ fontSize: 20, fontWeight: '800', flex: 1 }} numberOfLines={1}>{title}</Text>
        <Btn kind="ghost" small title="✕ Cerrar" onPress={onClose} />
      </View>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, paddingTop: 4, paddingBottom: 28 }} keyboardShouldPersistTaps="handled">
        {children}
      </ScrollView>
      {footer ? <View style={{ padding: 12, paddingBottom: 12 + ins.bottom, borderTopWidth: 1, borderColor: C.line, backgroundColor: C.card }}>{footer}</View> : null}
    </KeyboardAvoidingView>
  );
}
