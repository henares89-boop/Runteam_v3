import React, { useState } from 'react';
import { View, Text, ScrollView, Alert, Pressable } from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import { supabase } from './supabase';
import { Avatar, Btn, C, Chip, Chips, Sheet, s } from './ui';
import { addDays, fmtD, fmtDur, mondayOf, num, pad, paceText, sportInfo, sportKey, todayStr, weekStats, ymd } from './util';

/* ---------- lectura del activities.csv de Strava ---------- */
function parseCSV(t) {
  const rows = []; let r = [], f = '', q = false;
  for (let i = 0; i < t.length; i++) {
    const c = t[i];
    if (q) { if (c === '"') { if (t[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += c; }
    else if (c === '"') q = true;
    else if (c === ',') { r.push(f); f = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && t[i + 1] === '\n') i++; r.push(f); f = ''; if (r.length > 1 || r[0] !== '') rows.push(r); r = []; }
    else f += c;
  }
  if (f !== '' || r.length) { r.push(f); rows.push(r); }
  return rows;
}
const norm = (x) => String(x || '').normalize('NFD').replace(/[̀-ͯ]/g, '').trim().toLowerCase();
const MONTHS = { ene: 0, jan: 0, feb: 1, mar: 2, abr: 3, apr: 3, may: 4, jun: 5, jul: 6, ago: 7, aug: 7, sep: 8, set: 8, oct: 9, nov: 10, dic: 11, dec: 11 };
function parseDate(str) {
  str = String(str || '').trim(); if (!str) return null;
  let m = str.match(/(\d{1,2})\s*(?:de\s+)?([A-Za-zÀ-ÿ]+)\.?\s*,?\s*(?:de\s+)?(\d{4})(?:[,\s]+(\d{1,2}):(\d{2}))?/);
  if (m && MONTHS[norm(m[2]).slice(0, 3)] != null) return new Date(+m[3], MONTHS[norm(m[2]).slice(0, 3)], +m[1], +(m[4] || 12), +(m[5] || 0));
  m = str.match(/([A-Za-z]{3,})\.?\s+(\d{1,2}),?\s+(\d{4})(?:,?\s+(\d{1,2}):(\d{2})(?::\d{2})?\s*(AM|PM)?)?/i);
  if (m && MONTHS[norm(m[1]).slice(0, 3)] != null) {
    let h = +(m[4] || 12); const ap = (m[6] || '').toUpperCase();
    if (ap === 'PM' && h < 12) h += 12; if (ap === 'AM' && h === 12) h = 0;
    return new Date(+m[3], MONTHS[norm(m[1]).slice(0, 3)], +m[2], h, +(m[5] || 0));
  }
  const d = new Date(str); return isNaN(d) ? null : d;
}
const toNum = (v) => { v = String(v || '').trim(); if (!v) return NaN; if (v.includes(',') && !v.includes('.')) v = v.replace(',', '.'); else v = v.replace(/,/g, ''); return parseFloat(v); };

export function readStrava(text) {
  const rows = parseCSV(text.replace(/^﻿/, '')); if (rows.length < 2) throw new Error('El archivo está vacío');
  const H = rows[0].map(norm);
  const all = (names) => H.map((h, i) => (names.includes(h) ? i : -1)).filter((i) => i >= 0);
  const iId = all(['activity id', 'id de actividad', 'id de la actividad']), iDate = all(['activity date', 'fecha de la actividad', 'fecha de actividad']),
    iName = all(['activity name', 'nombre de la actividad', 'nombre de actividad']), iType = all(['activity type', 'tipo de actividad']),
    iDist = all(['distance', 'distancia']), iMov = all(['moving time', 'tiempo en movimiento']), iEl = all(['elapsed time', 'tiempo transcurrido']),
    iElev = all(['elevation gain', 'desnivel positivo', 'ganancia de elevacion']);
  if (!iDate.length || !iId.length || !iType.length) throw new Error('Este archivo no parece el activities.csv de Strava');
  const nums = (row, idx) => idx.map((i) => toNum(row[i])).filter((n) => !isNaN(n));
  const out = [];
  rows.slice(1).forEach((row) => {
    const d = parseDate(row[iDate[0]]); if (!d) return;
    const ds = nums(row, iDist);
    let km = 0;
    if (ds.length > 1) { const a = ds[0], b = ds[ds.length - 1]; km = Math.abs(b / 1000 - a) < Math.abs(b - a) ? b / 1000 : b; }
    else if (ds.length === 1) km = ds[0] > 300 ? ds[0] / 1000 : ds[0];
    let secs = nums(row, iMov); let sec = secs.length ? secs[secs.length - 1] : 0;
    if (!(sec > 0)) { secs = nums(row, iEl); sec = secs.length ? secs[secs.length - 1] : 0; }
    const sid = String(row[iId[0]] || '').replace(/\D/g, '');
    if (!sid || !(sec > 0 || km > 0)) return;
    const sport = String(row[iType[0]] || '');
    const el = nums(row, iElev);
    out.push({
      strava_id: Number(sid), date: ymd(d), started_at: ymd(d) + 'T' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':00Z',
      name: (iName.length && row[iName[0]]) || sportInfo(sportKey(sport))[0], sport: sportKey(sport),
      km: Math.round(km * 100) / 100, moving_sec: Math.round(sec), elev: el.length ? Math.round(el[el.length - 1]) : 0,
    });
  });
  return out;
}

/* ---------- importar ---------- */
export function ImportStrava({ me, onClose, reload }) {
  const [rows, setRows] = useState(null); const [per, setPer] = useState(90); const [onlyRun, setOnlyRun] = useState(false);
  const [busy, setBusy] = useState(false); const [msg, setMsg] = useState('');
  const cut = per ? ymd(new Date(Date.now() - per * 864e5)) : '0000-00-00';
  const sel = (rows || []).filter((r) => r.date >= cut && (!onlyRun || r.sport === 'run' || r.sport === 'trail'));
  const pick = async () => {
    try {
      const res = await DocumentPicker.getDocumentAsync({ type: '*/*', copyToCacheDirectory: true });
      if (res.canceled) return;
      const text = await (await fetch(res.assets[0].uri)).text();
      setRows(readStrava(text)); setMsg('');
    } catch (e) { setRows(null); setMsg(String(e.message || e)); }
  };
  const go = async () => {
    setBusy(true);
    for (let i = 0; i < sel.length; i += 100) {
      const chunk = sel.slice(i, i + 100).map((r) => ({ ...r, user_id: me.id, source: 'import' }));
      const { error } = await supabase.from('activities').upsert(chunk, { onConflict: 'strava_id', ignoreDuplicates: true });
      if (error) { setBusy(false); return Alert.alert('Error', error.message); }
    }
    setBusy(false); reload(); onClose();
    Alert.alert('Listo', 'Actividades importadas. Las que ya estaban se han omitido.');
  };
  return (
    <Sheet title="Importar de Strava" onClose={onClose}
      footer={rows ? <Btn title={busy ? 'Importando…' : 'Importar ' + sel.length + ' actividades'} onPress={go} disabled={busy || !sel.length} /> : null}>
      <Text style={{ lineHeight: 23 }}>
        1. En Strava (web): Configuración → Mi cuenta → Descarga o elimina tu cuenta → Solicitar tu archivo.{'\n'}
        2. Te llega un email con un ZIP. Descárgalo y extráelo.{'\n'}
        3. Pulsa el botón y elige el archivo activities.csv.{'\n'}
        Puedes repetirlo cuando quieras: no se duplica nada.
      </Text>
      <View style={{ marginTop: 14 }}><Btn title="Elegir activities.csv" onPress={pick} disabled={busy} /></View>
      {!!msg && <Text style={{ color: C.danger, marginTop: 10 }}>{msg}</Text>}
      {rows && (
        <View style={{ marginTop: 10 }}>
          <Text style={s.label}>PERIODO</Text>
          <Chips>{[[90, '3 meses'], [180, '6 meses'], [365, '1 año'], [0, 'Todo']].map(([v, l]) => <Chip key={l} label={l} on={per === v} onPress={() => setPer(v)} />)}</Chips>
          <Text style={s.label}>DEPORTES</Text>
          <Chips><Chip label="Todos" on={!onlyRun} onPress={() => setOnlyRun(false)} /><Chip label="Solo carrera / trail" on={onlyRun} onPress={() => setOnlyRun(true)} /></Chips>
          <View style={s.card}><Text>{rows.length} actividades en el archivo · {sel.length} con estos filtros</Text></View>
        </View>
      )}
    </Sheet>
  );
}

/* ---------- pantalla ---------- */
export default function Activities({ me, data, reload, go }) {
  const [viewer, setViewer] = useState(me.role === 'socio' ? 'all' : me.id);
  const [sp, setSp] = useState('all');
  const runners = data.profiles.filter((p) => p.role !== 'socio');
  const nm = (id) => (data.profiles.find((p) => p.id === id) || {}).name || '—';
  const cnt = (id) => data.cc.filter((c) => c.target_type === 'activity' && c.target_id === String(id)).length;
  const list = data.acts.filter((a) => (viewer === 'all' || a.user_id === viewer) && (sp === 'all' || sportKey(a.sport) === sp));
  const present = Array.from(new Set(data.acts.map((a) => sportKey(a.sport))));
  const ws = mondayOf(todayStr());
  const ids = viewer === 'all' ? runners.map((r) => r.id) : [viewer];
  const wst = ids.map((id) => weekStats(id, ws, data));
  const wkm = wst.reduce((x, y) => x + y.km, 0);
  const canAdd = me.role !== 'socio';
  let lastW = '';

  return (
    <ScrollView contentContainerStyle={{ padding: 14, paddingBottom: 40 }}>
      {canAdd && (
        <View style={s.card}>
          <Text style={{ fontWeight: '800', fontSize: 16 }}>Añadir mis actividades</Text>
          <Text style={[s.muted, { marginVertical: 6 }]}>Importa el archivo de Strava o regístralas a mano. Las sesiones del calendario se marcan solas si hay una actividad del mismo deporte ese día.</Text>
          <View style={{ gap: 8 }}>
            <Btn title="Importar archivo de Strava" onPress={() => go('import')} />
            <Btn kind="ghost" title="+ Registrar a mano" onPress={() => go('manual', { init: null })} />
          </View>
        </View>
      )}
      <Chips>
        {canAdd && <Chip label="Yo" on={viewer === me.id} onPress={() => setViewer(me.id)} />}
        <Chip label="Equipo" on={viewer === 'all'} onPress={() => setViewer('all')} />
        {runners.filter((r) => r.id !== me.id).map((r) => <Chip key={r.id} label={(r.name || '').split(' ')[0]} on={viewer === r.id} onPress={() => setViewer(r.id)} />)}
      </Chips>
      {present.length > 1 && (
        <Chips>
          <Chip label="Todos" on={sp === 'all'} onPress={() => setSp('all')} />
          {present.map((k) => <Chip key={k} label={sportInfo(k)[1] + ' ' + sportInfo(k)[0]} on={sp === k} onPress={() => setSp(k)} />)}
        </Chips>
      )}
      <View style={[s.card, { flexDirection: 'row', justifyContent: 'space-around' }]}>
        <View style={{ alignItems: 'center' }}><Text style={{ fontWeight: '800', fontSize: 17 }}>{num(wkm)} km</Text><Text style={s.muted}>Esta semana</Text></View>
        <View style={{ alignItems: 'center' }}><Text style={{ fontWeight: '800', fontSize: 17 }}>{list.length}</Text><Text style={s.muted}>Actividades</Text></View>
        <View style={{ alignItems: 'center' }}><Text style={{ fontWeight: '800', fontSize: 17 }}>{num(list.reduce((x, a) => x + Number(a.km || 0), 0), 0)} km</Text><Text style={s.muted}>Últ. 200 días</Text></View>
      </View>
      {!list.length && <Text style={[s.muted, { textAlign: 'center', marginTop: 24 }]}>Todavía no hay actividades.</Text>}
      {list.slice(0, 100).map((a) => {
        const k = sportKey(a.sport); const w = mondayOf(a.date); const head = w !== lastW; lastW = w;
        return (
          <View key={a.id}>
            {head && <Text style={s.h2}>Semana del {fmtD(w)} al {fmtD(addDays(w, 6))}</Text>}
            <Pressable onPress={() => go('comments', { target: { type: 'activity', id: a.id, title: a.name } })} style={s.card}>
              <View style={[s.row, { justifyContent: 'space-between' }]}>
                <Text style={{ fontWeight: '800', fontSize: 16, flex: 1 }}>{sportInfo(k)[1]} {Number(a.km) > 0 ? num(a.km, 2) + ' km · ' : ''}{fmtDur(a.moving_sec)}
                  <Text style={{ fontWeight: '400' }}>{paceText(k, a.moving_sec, a.km) ? ' · ' + paceText(k, a.moving_sec, a.km) : ''}</Text></Text>
                <Text style={s.muted}>💬 {cnt(a.id)}</Text>
              </View>
              <View style={[s.row, { marginTop: 4 }]}>
                <Avatar name={nm(a.user_id)} id={a.user_id} size={20} />
                <Text style={[s.muted, { flex: 1 }]}>{nm(a.user_id).split(' ')[0]} · {fmtD(a.date)} · {a.name} · {a.source === 'import' ? 'Strava (archivo)' : 'manual'}</Text>
              </View>
              {(a.user_id === me.id || me.role === 'coach') && (
                <Text style={{ color: C.danger, fontSize: 12, marginTop: 6 }} onPress={() => Alert.alert('¿Eliminar actividad?', '', [{ text: 'Cancelar' }, { text: 'Eliminar', style: 'destructive', onPress: async () => { await supabase.from('activities').delete().eq('id', a.id); reload(); } }])}>Eliminar</Text>
              )}
            </Pressable>
          </View>
        );
      })}
    </ScrollView>
  );
}
