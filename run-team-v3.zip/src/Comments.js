import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, TextInput, Switch, Alert } from 'react-native';
import { supabase } from './supabase';
import { Avatar, Btn, C, Chip, Chips, Pill, Sheet, s } from './ui';
import { fmtD, ROLES, ymd } from './util';

// target = { type: 'week'|'task'|'activity', id, title }
export default function Comments({ target, me, profiles, onClose, reload }) {
  const [list, setList] = useState([]); const [text, setText] = useState('');
  const [to, setTo] = useState(null); const [priv, setPriv] = useState(false);
  const name = (id) => (profiles.find((p) => p.id === id) || {}).name || 'Alguien';
  const load = useCallback(async () => {
    const { data } = await supabase.from('comments').select('*').eq('target_type', target.type).eq('target_id', String(target.id)).order('created_at');
    setList(data || []);
  }, [target.type, target.id]);
  useEffect(() => { load(); }, [load]);
  const send = async () => {
    if (!text.trim()) return;
    const { error } = await supabase.from('comments').insert({ target_type: target.type, target_id: String(target.id), body: text.trim(), to_user: to, private: priv });
    if (error) return Alert.alert('Error', error.message);
    setText(''); load(); reload();
  };
  const del = async (id) => { await supabase.from('comments').delete().eq('id', id); load(); reload(); };
  return (
    <Sheet title={target.title || 'Comentarios'} onClose={onClose}
      footer={(
        <View>
          <Chips>
            <Chip label="Para todos" on={!to} onPress={() => setTo(null)} />
            {profiles.filter((p) => p.id !== me.id).map((p) => <Chip key={p.id} label={'Para ' + (p.name || '').split(' ')[0]} on={to === p.id} onPress={() => setTo(p.id)} />)}
          </Chips>
          <TextInput style={[s.input, { minHeight: 56, maxHeight: 120, textAlignVertical: 'top' }]} multiline placeholder="Escribe un comentario…" value={text} onChangeText={setText} />
          <View style={[s.row, { justifyContent: 'space-between', marginTop: 8 }]}>
            {me.role === 'coach' ? <View style={s.row}><Switch value={priv} onValueChange={setPriv} /><Text style={s.muted}>Nota privada (coaches)</Text></View> : <View />}
            <Btn title="Enviar" onPress={send} disabled={!text.trim()} />
          </View>
        </View>
      )}>
      {!list.length && <Text style={[s.muted, { textAlign: 'center', marginTop: 24 }]}>Aún no hay comentarios. Sé el primero.</Text>}
      {list.map((c) => {
        const who = profiles.find((p) => p.id === c.author);
        return (
          <View key={c.id} style={[s.card, c.private && { backgroundColor: C.soft }]}>
            <View style={[s.row, { flexWrap: 'wrap' }]}>
              <Avatar name={name(c.author)} id={c.author} size={26} />
              <Text style={{ fontWeight: '700' }}>{name(c.author)}</Text>
              <Pill label={ROLES[(who && who.role) || 'runner']} kind={who && who.role === 'coach' ? 'coach' : undefined} />
              {c.to_user && <Text style={s.muted}>→ {name(c.to_user).split(' ')[0]}</Text>}
              {c.private && <Pill label="🔒 privada" kind="coach" />}
            </View>
            <Text style={{ marginTop: 6 }}>{c.body}</Text>
            <View style={[s.row, { justifyContent: 'space-between', marginTop: 6 }]}>
              <Text style={s.muted}>{fmtD(ymd(new Date(c.created_at)))}</Text>
              {(c.author === me.id || me.role === 'coach') && <Text style={{ color: C.danger, fontSize: 12 }} onPress={() => del(c.id)}>Borrar</Text>}
            </View>
          </View>
        );
      })}
    </Sheet>
  );
}
