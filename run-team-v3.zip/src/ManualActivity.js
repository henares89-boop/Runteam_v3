import React, { useState } from 'react';
import { Text, TextInput, Alert, View } from 'react-native';
import { supabase } from './supabase';
import { Btn, Chip, Chips, DateStrip, Sheet, s } from './ui';
import { HAS_DIST, SPORT_KEYS, parseClock, sportInfo, todayStr } from './util';

// init = { date, sport, km, min } para rellenar desde una sesión planificada
export default function ManualActivity({ me, init, onClose, reload }) {
  const [sport, setSport] = useState((init && init.sport) || 'run');
  const [date, setDate] = useState((init && init.date) || todayStr());
  const [km, setKm] = useState(init && init.km ? String(init.km) : '');
  const [dur, setDur] = useState(init && init.min ? String(init.min) : '');
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);

  const save = async () => {
    const sec = parseClock(dur);
    const k = km.trim() ? parseFloat(km.replace(',', '.')) : 0;
    if (!(sec > 0)) return Alert.alert('Falta la duración', 'Escribe los minutos (45), o mm:ss (42:30), o h:mm:ss (1:05:30).');
    if (isNaN(k) || k < 0) return Alert.alert('Distancia incorrecta');
    if (HAS_DIST.includes(sport) && !(k > 0)) return Alert.alert('Falta la distancia', 'Escribe los kilómetros.');
    setBusy(true);
    const { error } = await supabase.from('activities').insert({
      user_id: me.id, date, started_at: date + 'T12:00:00Z', name: name.trim() || sportInfo(sport)[0], sport, km: k, moving_sec: sec, source: 'manual',
    });
    setBusy(false);
    if (error) return Alert.alert('No se pudo guardar', error.message);
    reload(); onClose();
  };

  return (
    <Sheet title="Registrar actividad" onClose={onClose} footer={<Btn title={busy ? 'Guardando…' : 'Guardar'} onPress={save} disabled={busy} />}>
      <Text style={s.label}>DEPORTE</Text>
      <Chips>{SPORT_KEYS.map((k) => <Chip key={k} label={sportInfo(k)[1] + ' ' + sportInfo(k)[0]} on={sport === k} onPress={() => setSport(k)} />)}</Chips>
      <Text style={s.label}>FECHA</Text>
      <DateStrip value={date} onChange={setDate} />
      <View style={s.row}>
        <View style={{ flex: 1 }}>
          <Text style={s.label}>DISTANCIA (km)</Text>
          <TextInput style={s.input} keyboardType="decimal-pad" placeholder={HAS_DIST.includes(sport) ? 'Ej. 10,5' : 'Opcional'} value={km} onChangeText={setKm} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={s.label}>DURACIÓN</Text>
          <TextInput style={s.input} keyboardType="numbers-and-punctuation" placeholder="45 o 42:30" value={dur} onChangeText={setDur} />
        </View>
      </View>
      <Text style={[s.muted, { marginTop: 4 }]}>Duración: minutos (45), mm:ss (42:30) o h:mm:ss (1:05:30).</Text>
      <Text style={s.label}>NOMBRE (opcional)</Text>
      <TextInput style={s.input} maxLength={80} placeholder="Rodaje matinal" value={name} onChangeText={setName} />
    </Sheet>
  );
}
