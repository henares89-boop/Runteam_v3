import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, ScrollView, TextInput, Pressable, Alert, KeyboardAvoidingView } from 'react-native';
import { supabase } from './supabase';
import { Avatar, Btn, C, s } from './ui';
import { fmtLong, pad, ymd } from './util';

export const convKey = (m, myId) => (!m.to_user ? 'team' : m.author === myId ? m.to_user : m.author);
const hhmm = (iso) => { const d = new Date(iso); return pad(d.getHours()) + ':' + pad(d.getMinutes()); };

export default function Chat({ me, data, unread, markRead, onSent, reload }) {
  const [conv, setConv] = useState(null);
  const [text, setText] = useState(''); const [sending, setSending] = useState(false);
  const ref = useRef(null);
  const members = data.profiles.filter((p) => p.id !== me.id);
  const nm = (id) => (data.profiles.find((p) => p.id === id) || {}).name || 'Alguien';

  const convs = useMemo(() => {
    const map = {};
    data.msgs.forEach((m) => { const k = convKey(m, me.id); (map[k] = map[k] || []).push(m); });
    return map;
  }, [data.msgs, me.id]);

  const latest = conv && convs[conv] ? convs[conv][0] : null;
  useEffect(() => { if (conv && latest) markRead(conv, latest.created_at); }, [conv, latest && latest.id]);

  const send = async () => {
    const body = text.trim(); if (!body || sending) return;
    setSending(true);
    const { data: row, error } = await supabase.from('messages').insert({ to_user: conv === 'team' ? null : conv, body }).select().single();
    setSending(false);
    if (error) return Alert.alert('No se pudo enviar', error.message);
    setText(''); onSent(row);
  };
  const remove = (m) => {
    if (m.author !== me.id && me.role !== 'coach') return;
    Alert.alert('¿Borrar mensaje?', '', [{ text: 'Cancelar' }, { text: 'Borrar', style: 'destructive', onPress: async () => { await supabase.from('messages').delete().eq('id', m.id); reload(); } }]);
  };

  /* ---- lista de conversaciones ---- */
  if (!conv) {
    const items = [{ key: 'team', name: 'Equipo', sub: 'Chat de todo el grupo' }].concat(
      members.map((p) => ({ key: p.id, name: p.name || 'Sin nombre', sub: 'Mensaje directo' })),
    ).map((x) => ({ ...x, last: convs[x.key] ? convs[x.key][0] : null }));
    items.sort((a, b) => (b.key === 'team' ? 1 : 0) - (a.key === 'team' ? 1 : 0) || ((b.last ? b.last.created_at : '') > (a.last ? a.last.created_at : '') ? 1 : -1));
    items.sort((a, b) => (a.key === 'team' ? -1 : b.key === 'team' ? 1 : 0));
    return (
      <ScrollView contentContainerStyle={{ padding: 14, paddingBottom: 40 }}>
        <Text style={{ fontSize: 22, fontWeight: '800', marginBottom: 6 }}>Chat</Text>
        {items.map((x) => (
          <Pressable key={x.key} onPress={() => setConv(x.key)} style={[s.card, s.row]}>
            {x.key === 'team'
              ? <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: C.accent, alignItems: 'center', justifyContent: 'center' }}><Text style={{ fontSize: 20 }}>👥</Text></View>
              : <Avatar name={x.name} id={x.key} size={40} />}
            <View style={{ flex: 1 }}>
              <Text style={{ fontWeight: '800', fontSize: 16 }}>{x.name}</Text>
              <Text style={s.muted} numberOfLines={1}>{x.last ? (x.last.author === me.id ? 'Tú: ' : x.key === 'team' ? nm(x.last.author).split(' ')[0] + ': ' : '') + x.last.body : x.sub}</Text>
            </View>
            {(unread[x.key] || 0) > 0 && <View style={{ minWidth: 22, height: 22, borderRadius: 11, backgroundColor: C.accent, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6 }}><Text style={{ color: '#fff', fontWeight: '800', fontSize: 12 }}>{unread[x.key]}</Text></View>}
          </Pressable>
        ))}
      </ScrollView>
    );
  }

  /* ---- conversación ---- */
  const list = (convs[conv] || []).slice().reverse();
  const title = conv === 'team' ? 'Equipo' : nm(conv);
  let lastDay = '';
  return (
    <KeyboardAvoidingView behavior="padding" style={{ flex: 1 }}>
      <View style={[s.row, { padding: 12, borderBottomWidth: 1, borderColor: C.line, backgroundColor: C.card }]}>
        <Btn small kind="ghost" title="‹ Chats" onPress={() => setConv(null)} />
        {conv === 'team' ? <Text style={{ fontSize: 18 }}>👥</Text> : <Avatar name={title} id={conv} size={30} />}
        <Text style={{ fontWeight: '800', fontSize: 17, flex: 1 }} numberOfLines={1}>{title}</Text>
      </View>
      <ScrollView ref={ref} style={{ flex: 1 }} contentContainerStyle={{ padding: 12, paddingBottom: 8 }} keyboardShouldPersistTaps="handled"
        onContentSizeChange={() => ref.current && ref.current.scrollToEnd({ animated: false })}>
        {!list.length && <Text style={[s.muted, { textAlign: 'center', marginTop: 30 }]}>Aún no hay mensajes. Escribe el primero.</Text>}
        {list.map((m) => {
          const mineMsg = m.author === me.id; const day = ymd(new Date(m.created_at)); const head = day !== lastDay; lastDay = day;
          return (
            <View key={m.id}>
              {head && <Text style={[s.muted, { textAlign: 'center', marginVertical: 10 }]}>{fmtLong(day)}</Text>}
              <Pressable onLongPress={() => remove(m)} style={{ alignSelf: mineMsg ? 'flex-end' : 'flex-start', maxWidth: '82%', marginVertical: 3 }}>
                <View style={{ backgroundColor: mineMsg ? C.accent : C.card, borderRadius: 16, paddingVertical: 8, paddingHorizontal: 12, borderWidth: mineMsg ? 0 : 1, borderColor: C.line }}>
                  {!mineMsg && conv === 'team' && <Text style={{ fontWeight: '800', fontSize: 12, color: C.accent, marginBottom: 2 }}>{nm(m.author).split(' ')[0]}</Text>}
                  <Text style={{ color: mineMsg ? '#fff' : C.text, fontSize: 16 }}>{m.body}</Text>
                  <Text style={{ color: mineMsg ? '#ffd9c9' : C.muted, fontSize: 10, alignSelf: 'flex-end', marginTop: 2 }}>{hhmm(m.created_at)}</Text>
                </View>
              </Pressable>
            </View>
          );
        })}
      </ScrollView>
      <View style={[s.row, { padding: 10, alignItems: 'flex-end', borderTopWidth: 1, borderColor: C.line, backgroundColor: C.card }]}>
        <TextInput style={[s.input, { flex: 1, marginTop: 0, maxHeight: 110 }]} multiline placeholder="Escribe un mensaje…" value={text} onChangeText={setText} />
        <Btn title="Enviar" onPress={send} disabled={!text.trim() || sending} />
      </View>
    </KeyboardAvoidingView>
  );
}
