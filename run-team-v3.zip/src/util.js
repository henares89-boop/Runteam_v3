/* ---------- fechas ---------- */
export const pad = (n) => String(n).padStart(2, '0');
export const ymd = (d) => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
export const parse = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
export const todayStr = () => ymd(new Date());
export const addDays = (s, n) => { const d = parse(s); d.setDate(d.getDate() + n); return ymd(d); };
export const addMonths = (s, n) => {
  const d = parse(s); const day = d.getDate();
  d.setDate(1); d.setMonth(d.getMonth() + n);
  const dim = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
  d.setDate(Math.min(day, dim)); return ymd(d);
};
export const mondayOf = (s) => { const d = parse(s); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return ymd(d); };
export const weekdayIdx = (s) => (parse(s).getDay() + 6) % 7;
export const MES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
export const MESL = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
export const DIA = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
export const DIAI = ['L', 'M', 'X', 'J', 'V', 'S', 'D'];
export const fmtD = (s) => { const d = parse(s); return d.getDate() + ' ' + MES[d.getMonth()]; };
export const fmtLong = (s) => { const d = parse(s); return DIA[weekdayIdx(s)] + ' ' + d.getDate() + ' de ' + MESL[d.getMonth()]; };
export const fmtMonth = (s) => { const d = parse(s); return MESL[d.getMonth()] + ' ' + d.getFullYear(); };
export const fmtRange = (ws) => fmtD(ws) + ' – ' + fmtD(addDays(ws, 6));

/* ---------- números y tiempos ---------- */
export const num = (n, dec = 1) => { const f = Math.pow(10, dec); const v = Math.round(Number(n || 0) * f) / f; return String(v).replace('.', ','); };
export const fmtDur = (s) => {
  s = Math.round(s || 0); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60);
  return h ? h + ':' + pad(m) + ':' + pad(s % 60) : m + ':' + pad(s % 60);
};
export const fmtMin = (min) => {
  min = Number(min || 0);
  if (min < 60) return num(min, 0) + ' min';
  const h = Math.floor(min / 60), m = Math.round(min % 60);
  return m ? h + ' h ' + m + ' min' : h + ' h';
};
// "45" = 45 min · "42:30" = 42 min 30 s · "1:05:30" = 1 h 5 min 30 s
export const parseClock = (str) => {
  const t = String(str || '').trim().replace(',', '.');
  if (!t) return NaN;
  if (!t.includes(':')) { const v = parseFloat(t); return isNaN(v) ? NaN : Math.round(v * 60); }
  const p = t.split(':').map(Number);
  if (p.some(isNaN)) return NaN;
  if (p.length === 2) return p[0] * 60 + p[1];
  if (p.length === 3) return p[0] * 3600 + p[1] * 60 + p[2];
  return NaN;
};
// "400" = 400 m · "1,5" o "1.5k" = 1500 m
export const parseDistM = (str) => {
  const t = String(str || '').trim().toLowerCase().replace(',', '.');
  if (!t) return NaN;
  const v = parseFloat(t); if (isNaN(v)) return NaN;
  if (/k/.test(t)) return Math.round(v * 1000);
  if (t.includes('.') && v < 100) return Math.round(v * 1000);
  return Math.round(v);
};

/* ---------- deportes y tipos de sesión ---------- */
export const SPORTS = {
  run: ['Carrera', '🏃'], trail: ['Trail', '⛰️'], bike: ['Ciclismo', '🚴'], swim: ['Natación', '🏊'],
  walk: ['Caminata', '🚶'], strength: ['Fuerza', '🏋️'], other: ['Otro', '⚡'],
};
export const SPORT_KEYS = Object.keys(SPORTS);
export const sportInfo = (k) => SPORTS[k] || SPORTS.other;
export const sportKey = (str) => {
  const t = String(str || '').toLowerCase();
  if (SPORTS[t]) return t;
  if (/trail/.test(t)) return 'trail';
  if (/run|carrera|correr|corrida/.test(t)) return 'run';
  if (/ride|bike|cicl|bici/.test(t)) return 'bike';
  if (/swim|nata/.test(t)) return 'swim';
  if (/walk|hike|camin|sender/.test(t)) return 'walk';
  if (/weight|strength|workout|fuerza|gym|crossfit|yoga|pilates|pesas|entrenamiento/.test(t)) return 'strength';
  return 'other';
};
export const sportFamily = (k) => (k === 'trail' ? 'run' : k);
export const sameSport = (a, b) => a === 'other' || b === 'other' || sportFamily(a) === sportFamily(b);
export const HAS_DIST = ['run', 'trail', 'bike', 'swim', 'walk'];

export const TYPES = {
  rodaje: ['Rodaje', '#2e9e6b'], series: ['Series', '#e5484d'], tempo: ['Tempo', '#f08a24'],
  larga: ['Tirada larga', '#3e63dd'], recup: ['Recuperación', '#12a594'], competicion: ['Competición', '#d6409f'],
  descanso: ['Descanso', '#889096'], fuerza: ['Fuerza', '#8e4ec6'],
};
export const TYPE_PICK = ['rodaje', 'series', 'tempo', 'larga', 'recup', 'competicion', 'descanso'];
export const typeInfo = (k) => TYPES[k] || TYPES.rodaje;
export const ROLES = { coach: 'Coach', runner: 'Corredor/a', socio: 'Socio/a' };

export const paceText = (sport, sec, km) => {
  sec = Number(sec); km = Number(km);
  if (!sec || !km) return '';
  const f = sportFamily(sport);
  if (f === 'bike') return num(km / (sec / 3600), 1) + ' km/h';
  const mmss = (p) => { const t = Math.round(p); return Math.floor(t / 60) + ':' + pad(t % 60); };
  if (f === 'swim') return mmss(sec / (km * 10)) + '/100m';
  if (f === 'run' || f === 'walk') return mmss(sec / km) + '/km';
  return '';
};

/* ---------- estructura de la sesión (series) ---------- */
const durText = (m, v) => {
  v = Number(v);
  if (m === 'm') return v >= 1000 && v % 100 === 0 ? num(v / 1000, 2) + ' km' : v + ' m';
  if (v % 60 === 0) return v / 60 + ' min';
  if (v < 120) return v + ' s';
  return fmtDur(v) + ' min';
};
export function stepLine(st) {
  const pace = st.pace ? ' @ ' + st.pace : '';
  if (st.k === 'warm') return 'Calentamiento ' + durText(st.wm, st.wv) + pace;
  if (st.k === 'cool') return 'Enfriamiento ' + durText(st.wm, st.wv) + pace;
  if (st.k === 'steady') return 'Continuo ' + durText(st.wm, st.wv) + pace;
  return st.reps + '×' + durText(st.wm, st.wv) + pace + (Number(st.rv) > 0 ? ' · rec ' + durText(st.rm, st.rv) : '');
}
export function stepsTotals(steps) {
  let m = 0, s = 0;
  (steps || []).forEach((st) => {
    const r = st.k === 'rep' ? Number(st.reps) || 1 : 1;
    if (st.wm === 'm') m += r * st.wv; else s += r * st.wv;
    if (st.k === 'rep' && Number(st.rv) > 0 && r > 1) { if (st.rm === 'm') m += (r - 1) * st.rv; else s += (r - 1) * st.rv; }
  });
  return { m, s };
}
export function totalsText(t) {
  const p = [];
  if (t.m > 0) p.push('≈ ' + num(t.m / 1000, 2) + ' km');
  if (t.s > 0) p.push((t.m > 0 ? '+ ' : '≈ ') + fmtMin(t.s / 60));
  return p.join(' ');
}

/* ---------- tareas ---------- */
export const tDate = (t) => t.date || (t.day != null && t.week_start ? addDays(t.week_start, t.day) : null);
export const forUser = (t, uid) => !t.assignee || t.assignee === uid;
export const goalText = (t) => {
  const p = [];
  if (Number(t.km) > 0) p.push(num(t.km) + ' km');
  if (Number(t.goal_min) > 0) p.push(fmtMin(t.goal_min));
  return p.join(' · ');
};

// ¿Está hecha la tarea para este usuario? (marca manual o actividad del mismo deporte ese día)
export function taskStatus(t, uid, data) {
  if (data.done.some((d) => d.task_id === t.id && d.user_id === uid)) return { done: true, how: 'manual' };
  const date = tDate(t);
  if (!date || t.type === 'descanso') return { done: false };
  const sp = t.sport || 'run';
  const as = data.acts.filter((a) => a.user_id === uid && a.date === date && sameSport(sp, sportKey(a.sport)));
  if (!as.length) return { done: false };
  const km = as.reduce((x, a) => x + Number(a.km || 0), 0);
  const min = as.reduce((x, a) => x + Number(a.moving_sec || 0), 0) / 60;
  const gk = Number(t.km) || 0, gm = Number(t.goal_min) || 0;
  let ok = true;
  if (gk && gm) ok = km >= gk * 0.8 || min >= gm * 0.8;
  else if (gk) ok = km >= gk * 0.8;
  else if (gm) ok = min >= gm * 0.8;
  return ok ? { done: true, how: 'auto', km, min } : { partial: true, km, min };
}

export function weekStats(uid, ws, data) {
  const end = addDays(ws, 6);
  const tasks = data.tasks.filter((t) => { const d = tDate(t); return d && d >= ws && d <= end && forUser(t, uid) && t.type !== 'descanso'; });
  const done = tasks.filter((t) => taskStatus(t, uid, data).done).length;
  const acts = data.acts.filter((a) => a.user_id === uid && a.date >= ws && a.date <= end);
  return {
    total: tasks.length, done,
    km: acts.reduce((x, a) => x + Number(a.km || 0), 0),
    min: acts.reduce((x, a) => x + Number(a.moving_sec || 0), 0) / 60,
  };
}
