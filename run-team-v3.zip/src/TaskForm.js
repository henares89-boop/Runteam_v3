import React, { useState } from 'react';
import { View, Text, TextInput, Alert } from 'react-native';
import { supabase } from './supabase';
import { Btn, C, Chip, Chips, DateStrip, Seg, Sheet, s } from './ui';
import {
  SPORT_KEYS, TYPE_PICK, addDays, fmtMin, mondayOf, num, parseClock, parseDistM, sportInfo, stepLine, stepsTotals,
  tDate, todayStr, totalsText, typeInfo, weekdayIdx,
} from './util';

const KINDS = { warm: 'Calentamiento', rep: 'Series', steady: 'Continuo', cool: 'Enfriamiento' };
const newId = () => Math.random().toString(36).slice(2, 8);
const blankStep = (k) => ({
  id: newId(), k, reps: k === 'rep' ? '6' : '1', wu: k === 'rep' ? 'm' : 'min',
  wt: k === 'rep' ? '400' : k === 'cool' ? '10' : k === 'warm' ? '15' : '30', pace: '', ru: 's', rt: k === 'rep' ? '90' : '', note: '',
});
const mk = (k, o) => ({ ...blankStep(k), ...(o || {}) });
const TEMPLATES = [
  ['6×400 m', () => [mk('warm'), mk('rep', { reps: '6', wu: 'm', wt: '400', ru: 's', rt: '90' }), mk('cool')]],
  ['8×200 m', () => [mk('warm'), mk('rep', { reps: '8', wu: 'm', wt: '200', ru: 's', rt: '60' }), mk('cool')]],
  ['5×1 km', () => [mk('warm'), mk('rep', { reps: '5', wu: 'm', wt: '1000', ru: 'min', rt: '2' }), mk('cool')]],
  ['4×2 km', () => [mk('warm'), mk('rep', { reps: '4', wu: 'm', wt: '2000', ru: 'min', rt: '2' }), mk('cool')]],
  ['3×10 min tempo', () => [mk('warm'), mk('rep', { reps: '3', wu: 'min', wt: '10', ru: 'min', rt: '2' }), mk('cool')]],
  ['Fartlek 8×1′/1′', () => [mk('warm'), mk('rep', { reps: '8', wu: 'min', wt: '1', ru: 'min', rt: '1' }), mk('cool')]],
  ['Pirámide', () => [mk('warm'), ...[200, 400, 600, 800, 600, 400, 200].map((m) => mk('rep', { reps: '1', wu: 'm', wt: String(m), ru: 's', rt: '90' })), mk('cool')]],
];

function valOf(u, t) {
  t = String(t || '').trim();
  if (u === 'm') return parseDistM(t);
  if (u === 'min') return parseClock(t);
  if (t.includes(':')) return parseClock(t);
  const v = parseFloat(t.replace(',', '.'));
  return isNaN(v) ? NaN : Math.round(v);
}
function fromEdit(e) {
  const reps = e.k === 'rep' ? Math.max(1, parseInt(e.reps, 10) || 1) : 1;
  const wv = valOf(e.wu, e.wt);
  if (!(wv > 0)) return null;
  const st = { id: e.id, k: e.k, reps, wm: e.wu === 'm' ? 'm' : 's', wv, pace: (e.pace || '').trim(), note: (e.note || '').trim() };
  if (e.k === 'rep') {
    const rv = String(e.rt || '').trim() ? valOf(e.ru, e.rt) : 0;
    if (!(rv >= 0)) return null;
    st.rm = e.ru === 'm' ? 'm' : 's'; st.rv = rv;
  }
  return st;
}
function toEdit(st) {
  const un = (m, v) => (m === 'm' ? 'm' : v >= 60 && v % 60 === 0 ? 'min' : 's');
  const tx = (u, v) => (u === 'm' ? String(v) : u === 'min' ? String(v / 60) : String(v));
  const wu = un(st.wm, st.wv);
  let ru = 's', rt = '';
  if (st.k === 'rep' && st.rv) { ru = un(st.rm, st.rv); rt = tx(ru, st.rv); }
  return { id: st.id || newId(), k: st.k, reps: String(st.reps || 1), wu, wt: tx(wu, st.wv), pace: st.pace || '', ru, rt, note: st.note || '' };
}

const UnitChips = ({ value, onChange }) => (
  <View style={{ flexDirection: 'row', marginTop: 4 }}>
    {[['m', 'metros'], ['min', 'min'], ['s', 'seg']].map(([k, l]) => <Chip key={k} label={l} on={value === k} onPress={() => onChange(k)} />)}
  </View>
);

export default function TaskForm({ task, date: initDate, runners, onClose, reload }) {
  const editing = !!task;
  const [sport, setSport] = useState(task ? task.sport || 'run' : 'run');
  const [type, setType] = useState(task ? task.type || 'rodaje' : 'rodaje');
  const [title, setTitle] = useState(task ? task.title || '' : '');
  const [date, setDate] = useState((task && tDate(task)) || initDate || todayStr());
  const hasKm = task && Number(task.km) > 0, hasMin = task && Number(task.goal_min) > 0;
  const [goal, setGoal] = useState(task ? (hasKm && hasMin ? 'both' : hasKm ? 'dist' : hasMin ? 'time' : 'free') : 'dist');
  const [km, setKm] = useState(hasKm ? String(task.km) : '');
  const [min, setMin] = useState(hasMin ? String(task.goal_min) : '');
  const [steps, setSteps] = useState(task && Array.isArray(task.steps) ? task.steps.map(toEdit) : []);
  const [showSteps, setShowSteps] = useState(!!(task && Array.isArray(task.steps) && task.steps.length));
  const [assignee, setAssignee] = useState(task ? task.assignee || null : null);
  const [notes, setNotes] = useState(task ? task.notes || '' : '');
  const [busy, setBusy] = useState(false);
  const resting = type === 'descanso';

  const pickType = (k) => { setType(k); if (k === 'series' && !editing) setShowSteps(true); };
  const upd = (i, patch) => setSteps((a) => a.map((x, j) => (j === i ? { ...x, ...patch } : x)));
  const move = (i, d) => setSteps((a) => { const b = a.slice(); const j = i + d; if (j < 0 || j >= b.length) return a; const t = b[i]; b[i] = b[j]; b[j] = t; return b; });
  const del = (i) => setSteps((a) => a.filter((_, j) => j !== i));
  const add = (k) => setSteps((a) => [...a, blankStep(k)]);

  const valid = steps.map(fromEdit).filter(Boolean);
  const summary = valid.length ? totalsText(stepsTotals(valid)) : '';

  const buildRow = () => {
    let kmV = null, minV = null;
    if (!resting) {
      if (goal === 'dist' || goal === 'both') {
        const v = parseFloat(String(km).replace(',', '.'));
        if (!(v > 0)) { Alert.alert('Falta la distancia', 'Escribe los km o elige otro tipo de objetivo.'); return null; }
        kmV = v;
      }
      if (goal === 'time' || goal === 'both') {
        const v = parseFloat(String(min).replace(',', '.'));
        if (!(v > 0)) { Alert.alert('Falta el tiempo', 'Escribe los minutos del objetivo.'); return null; }
        minV = v;
      }
    }
    let st = null;
    if (!resting && showSteps && steps.length) {
      st = [];
      for (const e of steps) {
        const x = fromEdit(e);
        if (!x) { Alert.alert('Revisa la estructura', 'Algún bloque tiene la distancia o el tiempo vacío o mal escrito.'); return null; }
        st.push(x);
      }
    }
    let t = title.trim();
    if (!t) {
      const rep = st && st.find((x) => x.k === 'rep');
      t = rep ? 'Series ' + stepLine(rep) : typeInfo(type)[0] + (kmV ? ' ' + num(kmV) + ' km' : '') + (minV ? ' ' + fmtMin(minV) : '');
    }
    return {
      date, week_start: mondayOf(date), day: weekdayIdx(date), title: t, sport: resting ? 'other' : sport, type,
      km: kmV, goal_min: minV, steps: st, notes: notes.trim() || null, assignee,
    };
  };

  const save = async () => {
    const row = buildRow(); if (!row) return;
    setBusy(true);
    const { error } = editing ? await supabase.from('tasks').update(row).eq('id', task.id) : await supabase.from('tasks').insert(row);
    setBusy(false);
    if (error) return Alert.alert('No se pudo guardar', error.message);
    reload(); onClose();
  };
  const dup = async (days, label) => {
    const row = buildRow(); if (!row) return;
    const d2 = addDays(date, days);
    const { error } = await supabase.from('tasks').insert({ ...row, date: d2, week_start: mondayOf(d2), day: weekdayIdx(d2) });
    if (error) return Alert.alert('Error', error.message);
    reload(); Alert.alert('Duplicada', 'Copia creada ' + label + '.');
  };
  const remove = () => Alert.alert('¿Eliminar sesión?', 'Se borrarán también sus comentarios.', [
    { text: 'Cancelar' },
    { text: 'Eliminar', style: 'destructive', onPress: async () => { await supabase.from('tasks').delete().eq('id', task.id); reload(); onClose(); } },
  ]);

  return (
    <Sheet title={editing ? 'Editar sesión' : 'Nueva sesión'} onClose={onClose}
      footer={<View style={{ gap: 8 }}><Btn title={busy ? 'Guardando…' : 'Guardar sesión'} onPress={save} disabled={busy} />
        {editing && <View style={s.row}><Btn style={{ flex: 1 }} small kind="ghost" title="Copiar a mañana" onPress={() => dup(1, 'para mañana')} /><Btn style={{ flex: 1 }} small kind="ghost" title="Copiar +1 semana" onPress={() => dup(7, 'dentro de una semana')} /><Btn style={{ flex: 1 }} small kind="danger" title="Eliminar" onPress={remove} /></View>}</View>}>

      <Text style={s.label}>DEPORTE</Text>
      <Chips>{SPORT_KEYS.map((k) => <Chip key={k} label={sportInfo(k)[1] + ' ' + sportInfo(k)[0]} on={sport === k && !resting} onPress={() => { setSport(k); if (resting) setType('rodaje'); }} />)}</Chips>

      <Text style={s.label}>TIPO DE SESIÓN</Text>
      <Chips>{TYPE_PICK.map((k) => <Chip key={k} label={typeInfo(k)[0]} color={typeInfo(k)[1]} on={type === k} onPress={() => pickType(k)} />)}</Chips>

      <Text style={s.label}>FECHA</Text>
      <DateStrip value={date} onChange={setDate} />

      {!resting && (
        <View>
          <Text style={s.label}>OBJETIVO</Text>
          <Seg options={[['dist', 'Distancia'], ['time', 'Tiempo'], ['both', 'Ambos'], ['free', 'Libre']]} value={goal} onChange={setGoal} />
          {(goal === 'dist' || goal === 'both') && <TextInput style={s.input} keyboardType="decimal-pad" placeholder="Distancia en km (ej. 10)" value={km} onChangeText={setKm} />}
          {(goal === 'time' || goal === 'both') && <TextInput style={s.input} keyboardType="decimal-pad" placeholder="Tiempo en minutos (ej. 45)" value={min} onChangeText={setMin} />}
          {goal === 'free' && <Text style={[s.muted, { marginTop: 6 }]}>Sin cifra: se marca hecha con cualquier actividad de ese día.</Text>}

          <View style={[s.row, { justifyContent: 'space-between', marginTop: 16 }]}>
            <Text style={[s.label, { marginTop: 0 }]}>ESTRUCTURA (series, calentamiento…)</Text>
            <Btn small kind="ghost" title={showSteps ? 'Quitar' : 'Añadir'} onPress={() => { setShowSteps(!showSteps); }} />
          </View>
          {showSteps && (
            <View>
              <Text style={[s.muted, { marginBottom: 4 }]}>Empieza con una plantilla y cambia lo que quieras:</Text>
              <Chips>{TEMPLATES.map(([l, f]) => <Chip key={l} label={l} onPress={() => setSteps(f())} />)}</Chips>

              {steps.map((e, i) => (
                <View key={e.id} style={[s.card, { backgroundColor: C.bg }]}>
                  <View style={[s.row, { justifyContent: 'space-between' }]}>
                    <Text style={{ fontWeight: '800' }}>{i + 1}. {KINDS[e.k]}</Text>
                    <View style={s.row}>
                      <Btn small kind="ghost" title="↑" onPress={() => move(i, -1)} />
                      <Btn small kind="ghost" title="↓" onPress={() => move(i, 1)} />
                      <Btn small kind="danger" title="✕" onPress={() => del(i)} />
                    </View>
                  </View>
                  {e.k === 'rep' && <View><Text style={s.label}>Repeticiones</Text><TextInput style={[s.input, { width: 90 }]} keyboardType="number-pad" value={e.reps} onChangeText={(v) => upd(i, { reps: v })} /></View>}
                  <Text style={s.label}>{e.k === 'rep' ? 'Cada serie dura' : 'Duración'}</Text>
                  <UnitChips value={e.wu} onChange={(u) => upd(i, { wu: u })} />
                  <TextInput style={s.input} keyboardType="decimal-pad" placeholder={e.wu === 'm' ? 'Ej. 400, o 1,5 = 1,5 km' : e.wu === 'min' ? 'Ej. 10, o 1:30' : 'Ej. 45'} value={e.wt} onChangeText={(v) => upd(i, { wt: v })} />
                  <Text style={s.label}>Ritmo o intensidad (opcional)</Text>
                  <TextInput style={s.input} placeholder="Ej. 4:10/km, Z4, sensación dura" value={e.pace} onChangeText={(v) => upd(i, { pace: v })} />
                  {e.k === 'rep' && (
                    <View>
                      <Text style={s.label}>Recuperación entre series (vacío = sin descanso)</Text>
                      <UnitChips value={e.ru} onChange={(u) => upd(i, { ru: u })} />
                      <TextInput style={s.input} keyboardType="decimal-pad" placeholder={e.ru === 's' ? 'Ej. 90' : e.ru === 'min' ? 'Ej. 2' : 'Ej. 200'} value={e.rt} onChangeText={(v) => upd(i, { rt: v })} />
                    </View>
                  )}
                </View>
              ))}
              <Chips>
                <Chip label="+ Calentamiento" onPress={() => add('warm')} />
                <Chip label="+ Series" onPress={() => add('rep')} />
                <Chip label="+ Continuo" onPress={() => add('steady')} />
                <Chip label="+ Enfriamiento" onPress={() => add('cool')} />
              </Chips>
              {valid.length > 0 && (
                <View style={[s.card, { backgroundColor: C.okSoft }]}>
                  <Text style={{ fontWeight: '800', marginBottom: 4 }}>Así lo verán</Text>
                  {valid.map((x) => <Text key={x.id}>• {stepLine(x)}</Text>)}
                  {!!summary && <Text style={[s.muted, { marginTop: 4 }]}>Total aprox. {summary}</Text>}
                </View>
              )}
            </View>
          )}
        </View>
      )}

      <Text style={s.label}>TÍTULO (opcional)</Text>
      <TextInput style={s.input} maxLength={80} placeholder="Si lo dejas vacío se pone solo" value={title} onChangeText={setTitle} />

      <Text style={s.label}>PARA QUIÉN</Text>
      <Chips>
        <Chip label="Todo el equipo" on={!assignee} onPress={() => setAssignee(null)} />
        {runners.map((r) => <Chip key={r.id} label={(r.name || '').split(' ')[0]} on={assignee === r.id} onPress={() => setAssignee(r.id)} />)}
      </Chips>

      <Text style={s.label}>NOTAS</Text>
      <TextInput style={[s.input, { minHeight: 80, textAlignVertical: 'top' }]} multiline placeholder="Sensaciones, terreno, material…" value={notes} onChangeText={setNotes} />
    </Sheet>
  );
}
