import React, { useState } from 'react';
import { View, Text, ScrollView, TextInput, Alert, ActionSheetIOS, Platform } from 'react-native';
import { supabase } from './supabase';
import { Avatar, Btn, C, Pill, s } from './ui';
import { ROLES, fmtMin, mondayOf, num, todayStr, weekStats } from './util';

export default function Team({ me, data, reload }) {
  const [name, setName] = useState(me.name || ''); const [goal, setGoal] = useState(String(me.goal_km != null ? me.goal_km : 30));
  const ws = mondayOf(todayStr());
  const saveMe = async () => {
    const { error } = await supabase.from('profiles').update({ name: name.trim(), goal_km: parseFloat(goal.replace(',', '.')) || 30 }).eq('id', me.id);
    if (error) Alert.alert('Error', error.message); else { Alert.alert('Guardado'); reload(); }
  };
  const changeRole = (p) => {
    const opts = Object.keys(ROLES);
    const apply = async (r) => { const { error } = await supabase.rpc('set_role', { uid: p.id, r }); if (error) Alert.alert('Error', error.message); reload(); };
    if (Platform.OS === 'ios') ActionSheetIOS.showActionSheetWithOptions({ options: opts.map((o) => ROLES[o]).concat(['Cancelar']), cancelButtonIndex: opts.length }, (i) => { if (i < opts.length) apply(opts[i]); });
    else Alert.alert('Rol de ' + p.name, '', opts.map((o) => ({ text: ROLES[o], onPress: () => apply(o) })).concat([{ text: 'Cancelar', style: 'cancel' }]));
  };
  return (
    <ScrollView contentContainerStyle={{ padding: 14, paddingBottom: 40 }}>
      <Text style={s.h2}>Equipo</Text>
      <View style={s.card}>
        {data.profiles.map((p) => {
          const st = weekStats(p.id, ws, data);
          return (
            <View key={p.id} style={[s.row, { paddingVertical: 10, borderBottomWidth: 1, borderColor: C.line }]}>
              <Avatar name={p.name} id={p.id} size={38} />
              <View style={{ flex: 1 }}>
                <Text style={{ fontWeight: '800' }}>{p.name}{p.id === me.id ? ' (tú)' : ''}</Text>
                <Text style={s.muted}>Esta semana: {num(st.km)} km · {fmtMin(st.min)}{st.total ? ' · ' + st.done + '/' + st.total + ' sesiones' : ''}</Text>
              </View>
              {me.role === 'coach' ? <Btn kind="ghost" small title={ROLES[p.role] + ' ▾'} onPress={() => changeRole(p)} /> : <Pill label={ROLES[p.role]} kind={p.role === 'coach' ? 'coach' : undefined} />}
            </View>
          );
        })}
      </View>
      <Text style={[s.muted, { marginTop: 6 }]}>Coach: crea sesiones y semanas, y escribe notas privadas. Corredor/a: registra actividades, marca sesiones y comenta. Socio/a: sigue al equipo, comenta y chatea.</Text>

      <Text style={s.h2}>Mi perfil</Text>
      <View style={s.card}>
        <Text style={s.label}>NOMBRE</Text><TextInput style={s.input} value={name} onChangeText={setName} />
        <Text style={s.label}>OBJETIVO SEMANAL POR DEFECTO (km)</Text><TextInput style={s.input} keyboardType="decimal-pad" value={goal} onChangeText={setGoal} />
        <View style={{ marginTop: 12, gap: 8 }}>
          <Btn title="Guardar" onPress={saveMe} />
          <Btn kind="ghost" title="Cerrar sesión" onPress={() => supabase.auth.signOut()} />
        </View>
      </View>
    </ScrollView>
  );
}
