import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, Pressable, StatusBar, ActivityIndicator, BackHandler, AppState, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { supabase } from './src/supabase';
import Auth from './src/Auth';
import Calendar, { WeekForm } from './src/Calendar';
import Activities, { ImportStrava } from './src/Activities';
import Chat, { convKey } from './src/Chat';
import Team from './src/Team';
import Comments from './src/Comments';
import TaskForm from './src/TaskForm';
import ManualActivity from './src/ManualActivity';
import { Btn, C, s } from './src/ui';
import { ymd } from './src/util';

const TABS = [['cal', 'Calendario', '📅'], ['acts', 'Actividades', '🏃'], ['chat', 'Chat', '💬'], ['team', 'Equipo', '👥']];
const TABLES = ['tasks', 'weeks', 'activities', 'task_done', 'profiles', 'comments', 'messages'];

export default function App() {
  return <SafeAreaProvider><Root /></SafeAreaProvider>;
}

function Root() {
  const ins = useSafeAreaInsets();
  const [session, setSession] = useState(undefined);
  const [tab, setTab] = useState('cal');
  const [data, setData] = useState(null);
  const [loadErr, setLoadErr] = useState(null);
  const [overlay, setOverlay] = useState(null);
  const [lastRead, setLastRead] = useState({});
  const timer = useRef(null);
  const uid = session && session.user ? session.user.id : null;

  useEffect(() => {
    supabase.auth.getSession().then(({ data: d }) => setSession(d.session));
    const { data: l } = supabase.auth.onAuthStateChange((_e, sn) => setSession(sn));
    return () => l.subscription.unsubscribe();
  }, []);

  const load = useCallback(async () => {
    try {
      const since = ymd(new Date(Date.now() - 200 * 864e5));
      const [p, t, w, a, d, c, m] = await Promise.all([
        supabase.from('profiles').select('*').order('name'),
        supabase.from('tasks').select('*'),
        supabase.from('weeks').select('*'),
        supabase.from('activities').select('*').gte('date', since).order('started_at', { ascending: false }),
        supabase.from('task_done').select('*'),
        supabase.from('comments').select('target_type,target_id'),
        supabase.from('messages').select('*').order('created_at', { ascending: false }).limit(400),
      ]);
      if (p.error) throw p.error;
      if (t.error) throw t.error;
      setData({
        profiles: p.data || [], tasks: t.data || [], weeks: w.data || [], acts: a.data || [], done: d.data || [],
        cc: c.data || [], msgs: m.data || [], noChat: !!m.error,
      });
      setLoadErr(null);
    } catch (e) { setLoadErr(String((e && e.message) || e)); }
  }, []);
  const reload = useCallback(() => {
    clearTimeout(timer.current);
    return new Promise((res) => { timer.current = setTimeout(() => load().then(res), 150); });
  }, [load]);

  useEffect(() => {
    if (!uid) { setData(null); return undefined; }
    load();
    let ch = supabase.channel('rt-' + uid);
    TABLES.forEach((table) => { ch = ch.on('postgres_changes', { event: '*', schema: 'public', table }, () => reload()); });
    ch.subscribe();
    const sub = AppState.addEventListener('change', (st) => { if (st === 'active') load(); });
    AsyncStorage.getItem('lastRead:' + uid).then((v) => { if (v) { try { setLastRead(JSON.parse(v)); } catch (e) { /* ignorar */ } } });
    return () => { supabase.removeChannel(ch); sub.remove(); };
  }, [uid]);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => { if (overlay) { setOverlay(null); return true; } return false; });
    return () => sub.remove();
  }, [overlay]);

  const me = data && data.profiles.find((p) => p.id === uid);
  const markRead = useCallback((key, ts) => {
    setLastRead((prev) => {
      if (prev[key] && prev[key] >= ts) return prev;
      const next = { ...prev, [key]: ts };
      AsyncStorage.setItem('lastRead:' + uid, JSON.stringify(next));
      return next;
    });
  }, [uid]);
  const unread = useMemo(() => {
    const u = {};
    if (!data || !me) return u;
    data.msgs.forEach((m) => {
      if (m.author === me.id) return;
      const k = convKey(m, me.id);
      if (!lastRead[k] || m.created_at > lastRead[k]) u[k] = (u[k] || 0) + 1;
    });
    return u;
  }, [data, me, lastRead]);
  const unreadTotal = Object.keys(unread).reduce((x, k) => x + unread[k], 0);
  const onSent = useCallback((row) => { setData((d) => (d ? { ...d, msgs: [row].concat(d.msgs.filter((m) => m.id !== row.id)) } : d)); }, []);

  const go = (name, props) => setOverlay({ name, props: props || {} });
  const close = () => setOverlay(null);

  const renderOverlay = () => {
    const p = overlay.props;
    const runners = data.profiles.filter((x) => x.role !== 'socio');
    if (overlay.name === 'task') return <TaskForm task={p.task} date={p.date} runners={runners} onClose={close} reload={reload} />;
    if (overlay.name === 'manual') return <ManualActivity me={me} init={p.init} onClose={close} reload={reload} />;
    if (overlay.name === 'import') return <ImportStrava me={me} onClose={close} reload={reload} />;
    if (overlay.name === 'week') return <WeekForm ws={p.ws} focus={p.focus} onClose={close} reload={reload} />;
    if (overlay.name === 'comments') return <Comments target={p.target} me={me} profiles={data.profiles} onClose={close} reload={reload} />;
    return null;
  };

  if (session === undefined) return <View style={{ flex: 1, justifyContent: 'center', backgroundColor: C.bg }}><ActivityIndicator /></View>;

  let body;
  if (!session) body = <Auth />;
  else if (loadErr && !data) {
    body = (
      <View style={{ flex: 1, justifyContent: 'center', padding: 24 }}>
        <Text style={{ fontSize: 18, fontWeight: '800' }}>No se pudieron cargar los datos</Text>
        <Text style={[s.muted, { marginVertical: 10 }]}>{loadErr}</Text>
        <Btn title="Reintentar" onPress={load} />
        <View style={{ height: 8 }} /><Btn kind="ghost" title="Cerrar sesión" onPress={() => supabase.auth.signOut()} />
      </View>
    );
  } else if (!data) body = <View style={{ flex: 1, justifyContent: 'center' }}><ActivityIndicator /></View>;
  else if (!me) {
    body = (
      <View style={{ flex: 1, justifyContent: 'center', padding: 24 }}>
        <Text style={{ fontSize: 18, fontWeight: '800' }}>No encontramos tu perfil</Text>
        <Text style={[s.muted, { marginVertical: 10 }]}>Tu cuenta existe pero no tiene perfil en la base de datos. Pide al coach que lo revise en Supabase.</Text>
        <Btn title="Reintentar" onPress={load} />
        <View style={{ height: 8 }} /><Btn kind="ghost" title="Cerrar sesión" onPress={() => supabase.auth.signOut()} />
      </View>
    );
  } else {
    body = (
      <View style={{ flex: 1 }}>
        {data.noChat && (
          <View style={{ backgroundColor: C.warnSoft, padding: 10 }}>
            <Text style={{ color: C.warn, fontWeight: '700' }}>Falta ejecutar la actualización v3 en Supabase (migracion_v3.sql). Sin ella no funcionan el chat ni las series.</Text>
          </View>
        )}
        <View style={{ flex: 1 }}>
          {tab === 'cal' && <Calendar me={me} data={data} reload={reload} go={go} />}
          {tab === 'acts' && <Activities me={me} data={data} reload={reload} go={go} />}
          {tab === 'chat' && <Chat me={me} data={data} unread={unread} markRead={markRead} onSent={onSent} reload={reload} />}
          {tab === 'team' && <Team me={me} data={data} reload={reload} />}
        </View>
        <View style={{ flexDirection: 'row', borderTopWidth: 1, borderColor: C.line, backgroundColor: C.card, paddingBottom: ins.bottom }}>
          {TABS.map(([k, label, ic]) => (
            <Pressable key={k} onPress={() => setTab(k)} style={{ flex: 1, alignItems: 'center', paddingVertical: 8 }}>
              <View>
                <Text style={{ fontSize: 22 }}>{ic}</Text>
                {k === 'chat' && unreadTotal > 0 && (
                  <View style={{ position: 'absolute', top: -2, right: -10, minWidth: 18, height: 18, borderRadius: 9, backgroundColor: C.accent, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 4 }}>
                    <Text style={{ color: '#fff', fontSize: 10, fontWeight: '800' }}>{unreadTotal > 99 ? '99+' : unreadTotal}</Text>
                  </View>
                )}
              </View>
              <Text style={{ fontSize: 11, color: tab === k ? C.accent : C.muted, fontWeight: tab === k ? '800' : '400' }}>{label}</Text>
            </Pressable>
          ))}
        </View>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <StatusBar barStyle="dark-content" />
      <View style={{ flex: 1, paddingTop: ins.top }}>{body}</View>
      {overlay && data && me ? <View style={[StyleSheet.absoluteFill, { backgroundColor: C.bg }]}>{renderOverlay()}</View> : null}
    </View>
  );
}
