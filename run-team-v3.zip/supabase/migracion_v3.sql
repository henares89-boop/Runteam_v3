-- RUN TEAM v3 · Ejecuta esto ENTERO en Supabase > SQL Editor > New query > Run.
-- Se puede ejecutar más de una vez sin problema. No borra nada de lo que ya tienes.

-- 1) Sesiones: fecha exacta, deporte, objetivo por tiempo y estructura de series
alter table tasks add column if not exists date date;
alter table tasks add column if not exists sport text default 'run';
alter table tasks add column if not exists goal_min numeric;
alter table tasks add column if not exists steps jsonb;

update tasks set date = week_start + day where date is null and day is not null;
update tasks set sport = 'strength' where type = 'fuerza' and (sport is null or sport = 'run');
update tasks set sport = 'run' where sport is null;

-- 2) Chat (equipo y mensajes directos)
create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  author uuid not null default auth.uid() references profiles(id) on delete cascade,
  to_user uuid references profiles(id) on delete cascade,   -- null = chat del equipo
  body text not null check (length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);
create index if not exists messages_created_idx on messages (created_at desc);

alter table messages enable row level security;
grant select, insert, delete on messages to authenticated;

drop policy if exists m_sel on messages;
drop policy if exists m_ins on messages;
drop policy if exists m_del on messages;
create policy m_sel on messages for select to authenticated
  using (to_user is null or author = auth.uid() or to_user = auth.uid());
create policy m_ins on messages for insert to authenticated
  with check (author = auth.uid());
create policy m_del on messages for delete to authenticated
  using (author = auth.uid() or is_coach());

-- 3) Mensajes en tiempo real
do $$ begin
  alter publication supabase_realtime add table messages;
exception when duplicate_object then null;
end $$;

-- Comprobación: debe devolver 1 fila con las columnas nuevas y la tabla messages
select
  (select count(*) from information_schema.columns where table_name = 'tasks' and column_name in ('date','sport','goal_min','steps')) as columnas_nuevas_de_4,
  (select count(*) from information_schema.tables where table_name = 'messages') as tabla_chat;
