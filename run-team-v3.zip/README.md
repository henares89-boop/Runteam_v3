# Run Team v3 (Android + iPhone)

Expo (React Native) + Supabase. Calendario mensual/semanal, sesiones con series, objetivo por distancia o tiempo,
varios deportes, actividades (archivo de Strava o a mano), comentarios y chat.

## Actualizar desde la v2
1. Supabase > SQL Editor > pega `supabase/migracion_v3.sql` > Run. Debe devolver `4` y `1`.
2. Sube este zip a tu repositorio de GitHub (Add file > Upload files).
3. En `.github/workflows/build.yml` cambia 2 líneas (ver instrucciones del chat) y ejecuta Actions > Build APK > Run workflow.
4. Instala el APK nuevo encima del anterior (se conservan tu cuenta y tus datos).
